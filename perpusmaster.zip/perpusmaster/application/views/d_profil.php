 <div class="span9">
		<ul class="breadcrumb wellwhite">
			<li><a href="<?=base_URL()?>">Beranda</a> <span class="divider">/</span></li>
			<li>Profil Perpustakaan </li>
		</ul>
		
		<div class="span12 wellwhite" style="margin-left: 0px">
		<legend style="margin-bottom: 10px; font-size: 15px; font-weight: bold">Profil Perpustakaan <?=$q_instansi->nama?></legend>
		<div class="row-fluid">
		<?=$data->profil?>		
		
        </div>
		</div>        
</div><!--/span-->